# adeen.xyz

Personal site. Plain HTML, no build step.

- Post notes and pictures at adeen.xyz/admin (log in with GitHub).
- Notes live in data/notes.json, pictures in data/photos.json, uploads in images/uploads.
