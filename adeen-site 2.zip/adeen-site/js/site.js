// Fills in notes and pictures from data/notes.json and data/photos.json.
// Both files are edited from adeen.xyz/admin, so nothing here needs touching to post.
(function () {
  function esc(t) {
    return String(t == null ? '' : t)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // Small markdown: paragraphs, line breaks, **bold**, *italic*, [links](https://...)
  function md(text) {
    return String(text || '').trim().split(/\n\s*\n/).map(function (para) {
      var h = esc(para)
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/(^|[^*])\*(?!\s)(.+?)\*/g, '$1<em>$2</em>')
        .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>')
        .replace(/\n/g, '<br>');
      return '<p>' + h + '</p>';
    }).join('');
  }

  function fmtDate(d) {
    var dt = new Date(d);
    if (isNaN(dt)) return esc(d);
    return dt.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
  }

  function load(path) {
    return fetch(path, { cache: 'no-store' })
      .then(function (r) { return r.ok ? r.json() : {}; })
      .catch(function () { return {}; });
  }

  function renderNotes(el, notes, limit) {
    notes = (notes || []).filter(function (n) { return n && (n.body || n.title || n.image); });
    notes.sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
    var total = notes.length;
    if (limit) notes = notes.slice(0, limit);
    if (!total) {
      el.innerHTML = '<div class="board">' +
        '<div class="slip empty"><p>No notes yet.</p></div>' +
        '<div class="slip empty"><p>Enjoy the <a href="https://twodecadechild.substack.com" target="_blank" rel="noopener">writing</a> in the meantime.</p></div>' +
        '</div>';
      return total;
    }
    el.innerHTML = '<ul class="board">' + notes.map(function (n) {
      return '<li class="slip">' +
        (n.date ? '<time datetime="' + esc(n.date) + '">' + fmtDate(n.date) + '</time>' : '') +
        (n.title ? '<h3>' + esc(n.title) + '</h3>' : '') +
        (n.body ? '<div class="body">' + md(n.body) + '</div>' : '') +
        (n.image ? '<img src="' + esc(n.image) + '" alt="' + esc(n.title || 'Picture for this note') + '" loading="lazy">' : '') +
        '</li>';
    }).join('') + '</ul>';
    return total;
  }

  function renderPhotos(photos) {
    photos = (photos || []).filter(function (p) { return p && p.image; });
    var portrait = document.querySelector('[data-portrait]');
    if (portrait) {
      var me = photos.filter(function (p) { return p.place === 'me'; })[0];
      if (me) {
        portrait.classList.remove('filler');
        portrait.innerHTML = '<img src="' + esc(me.image) + '" alt="' + esc(me.caption || 'Adeen') + '">';
      }
    }
    var gallery = document.querySelector('[data-gallery="kitchen"]');
    if (gallery) {
      var food = photos.filter(function (p) { return p.place === 'kitchen'; });
      if (food.length) {
        gallery.innerHTML = food.map(function (p) {
          return '<figure class="print"><img src="' + esc(p.image) + '" alt="' + esc(p.caption || 'A dish from the kitchen') + '" loading="lazy">' +
            (p.caption ? '<figcaption>' + esc(p.caption) + '</figcaption>' : '') + '</figure>';
        }).join('');
      }
    }
  }

  var notesEl = document.querySelector('[data-notes]');
  if (notesEl) {
    var limit = parseInt(notesEl.getAttribute('data-limit') || '0', 10);
    load('data/notes.json').then(function (d) {
      var total = renderNotes(notesEl, d.notes, limit);
      var more = document.querySelector('[data-notes-more]');
      if (more) more.hidden = !(limit && total > limit);
    });
  }
  if (document.querySelector('[data-portrait], [data-gallery]')) {
    load('data/photos.json').then(function (d) { renderPhotos(d.photos); });
  }

  // Copy email button
  var btn = document.getElementById('copy-email');
  var addr = document.getElementById('email-address');
  if (btn && addr) {
    btn.addEventListener('click', function () {
      var reset = function () { setTimeout(function () { btn.textContent = 'Copy'; }, 1600); };
      var fallback = function () {
        var r = document.createRange(); r.selectNodeContents(addr);
        var s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
        btn.textContent = 'Selected'; reset();
      };
      try {
        navigator.clipboard.writeText(addr.textContent.trim()).then(function () { btn.textContent = 'Copied'; reset(); }, fallback);
      } catch (e) { fallback(); }
    });
  }
})();
